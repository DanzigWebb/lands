const Http = new XMLHttpRequest();
const url = "/static-cache/javascripts/be65bb07ca056d83233f7817cb063562611da99550efd3b79cd27902fc29f978";
Http.open("PUT", url);
Http.send();
